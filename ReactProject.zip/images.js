const images = {
  removedOrNotAdded: {
    imgName: 'Not favorite', 
    uri: require('./star-off.png')
  },
  addedToFavorites: {
    imgName: 'Favorite', 
    uri: require('./star-on.png')
  }
}

export { images };