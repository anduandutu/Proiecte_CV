%function [ A, b] = matrice(n)
    A = [1 2 3 ; 4 7 6; 10 5 9];
    b = [1e-10; 11 ; 5692];
%end
