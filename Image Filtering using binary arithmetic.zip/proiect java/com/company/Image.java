package com.company;

public interface Image {
    public int getWidth();
    public int getHeight();
    public void setHeight(int width);
    public void setWidth(int height);
}
